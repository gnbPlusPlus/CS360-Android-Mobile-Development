package com.noellebishop.projectstuff.fragments;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.noellebishop.projectstuff.DBHelper;
import com.noellebishop.projectstuff.MainActivity;
import com.noellebishop.projectstuff.R;
import com.noellebishop.projectstuff.model.Event;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import adapter.EventAdapter;

public class UpcomingEventsFragment extends Fragment {

    private EditText eventInput;  // Event name field
    private Button dateButton;
    private EventAdapter adapter;
    private DBHelper dbHelper;
    private List<Event> eventList;
    private String selectedDate = "";  // Event date field

    public UpcomingEventsFragment() {
        // Required empty public constructor (in response to compiler warning)
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_upcoming_events, container, false);

        // All relevant views are initialized for use throughout the fragment
        eventInput = view.findViewById(R.id.eventInput);
        dateButton = view.findViewById(R.id.dateButton);
        Button addButton = view.findViewById(R.id.addButton);
        RecyclerView eventRecyclerView = view.findViewById(R.id.eventRecyclerView);

        dbHelper = new DBHelper(requireContext());

        // Get logged-in user's ID for displaying their specific events
        SharedPreferences prefs = requireActivity().getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        int userId = prefs.getInt("loggedInUserId", -1);

        // RecyclerView (with fragments!) setup
        eventList = new ArrayList<>();
        adapter = new EventAdapter(eventList, new EventAdapter.OnEventActionListener() {
            @Override
            public void onEdit(Event event) {
                // When clicked, the Edit button takes the user to the Edit Event screen & fragment
                EditEventFragment editFragment = EditEventFragment.newInstance(event.getId(), event.getName(), event.getDate());
                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, editFragment)
                        .addToBackStack(null)
                        .commit();
            }

            // Deleting an event doesn't require any screen or fragment switches
            @Override
            public void onDelete(Event event) {
                dbHelper.deleteEvent(event.getId());
                loadEventsForUser(userId); // refresh list
                Toast.makeText(requireContext(), "The event was deleted. See ya!", Toast.LENGTH_SHORT).show();
            }
        });

        eventRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        eventRecyclerView.setAdapter(adapter);

        if (userId != -1) {
            loadEventsForUser(userId);
        }

        // Date picker click listener setup
        dateButton.setOnClickListener(v -> showDatePicker());

        // Add button click listener setup
        addButton.setOnClickListener(v -> addEventForUser(userId));

        return view;
    }

    // The date button is merely a button in XML...
    // But with the power of Java, it becomes capable of selecting a date from a calendar
    // Guidance: https://www.geeksforgeeks.org/android/datepicker-in-android/
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(requireContext(),
                (view, year1, month1, dayOfMonth) -> {
                    selectedDate = (month1 + 1) + "/" + dayOfMonth + "/" + year1;
                    dateButton.setText(selectedDate);
                }, year, month, day);
        dialog.show();
    }

    // Add an event for a specific user (not just a general-use, free-for-all table)
    private void addEventForUser(int userId) {
        String name = eventInput.getText().toString().trim();

        if (name.isEmpty() || selectedDate.isEmpty()) {
            Toast.makeText(requireContext(), "Make sure you selected a name AND date!", Toast.LENGTH_SHORT).show();
            return;
        }

        long inserted = dbHelper.addEventForUser(userId, name, selectedDate);
        if (inserted != -1) {
            Toast.makeText(requireContext(), "Event added!", Toast.LENGTH_SHORT).show();

            // Check SMS permission for first-time users
            checkSmsPermissionFirstTime();

            // Placeholder phone number for SMS testing
            String phoneNumber = "1234567890";

            // Send Log message to test SMS notification
            String message = "Reminder: " + name + " is happening on " + selectedDate;
            sendSmsNotification(phoneNumber, message);

            // Clear fields for next event input
            eventInput.setText("");
            dateButton.setText(R.string.select_date_button);
            selectedDate = "";
            loadEventsForUser(userId);  // Refresh the events list
        } else {
            Toast.makeText(requireContext(), "Event not added due to error.", Toast.LENGTH_SHORT).show();
        }
        // Notify the adapter of list changes (prevents a blank list)
        adapter.notifyDataSetChanged();
    }

    // Load all the user's events in RecyclerView display
    private void loadEventsForUser(int userId) {
        eventList.clear(); // reset
        Cursor cursor = dbHelper.getEventsForUser(userId);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int eventId = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_EVENT_ID));
                String eventName = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_EVENT_NAME));
                String eventDate = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_EVENT_DATE));
                eventList.add(new Event(eventId, eventName, eventDate));
            }
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    // This function triggers when the user adds their first event
    // Guidance was plucked from several places in zyBooks examples
    private void checkSmsPermissionFirstTime() {
        // SharedPreferences tracks if permission has been requested before
        SharedPreferences prefs = requireContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
        boolean askedBefore = prefs.getBoolean("smsPermissionRequested", false);

        if (!askedBefore) {
            // Launch the SMS permission fragment
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).switchToFragment(new SmsFragment());
            }

            // Mark as asked so the app doesn't ask again (that would be annoying!)
            prefs.edit().putBoolean("smsPermissionRequested", true).apply();
        }
    }

    // This function sends a mock SMS notification to Logcat for testing purposes
    // Guidance found in: https://www.geeksforgeeks.org/android/sending-a-text-message-over-the-phone-using-smsmanager-in-android/
    private void sendSmsNotification(String phoneNumber, String message) {
        // If send SMS permission was granted...
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                // Debug SMS message
                Log.d("SMS_TEST", "SMS sent to " + phoneNumber + ": " + message);
            } catch (Exception e) {
                Toast.makeText(requireContext(), "SMS did not send due to error.", Toast.LENGTH_SHORT).show();
            }

        } else {
            Toast.makeText(requireContext(), "SMS permission wasn't given, so there's nothing to send.", Toast.LENGTH_SHORT).show();
        }
    }
}

