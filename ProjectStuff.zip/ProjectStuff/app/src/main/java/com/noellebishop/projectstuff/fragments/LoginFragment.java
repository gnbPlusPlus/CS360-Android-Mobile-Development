package com.noellebishop.projectstuff.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.noellebishop.projectstuff.DBHelper;
import com.noellebishop.projectstuff.MainActivity;
import com.noellebishop.projectstuff.R;

// Guidance for login and account creation functionality was found in Android documentation:
// https://developer.android.com/guide/navigation/use-graph/conditional

public class LoginFragment extends Fragment {
    private EditText usernameInput, passwordInput;
    private DBHelper dbHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        usernameInput = view.findViewById(R.id.username_input);
        passwordInput = view.findViewById(R.id.password_input);
        Button loginButton = view.findViewById(R.id.login_button);
        Button createAccountButton = view.findViewById(R.id.create_account_button);

        dbHelper = new DBHelper(getContext());

        // Handle login
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            int userId = dbHelper.checkUserLogin(username, password);

            // Check if user already exists in database
            if ((userId != -1)) {
                // Get the user's preferences, i.e. their events
                requireActivity()
                        .getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                        .edit()
                        .putInt("loggedInUserId", userId)
                        .apply();

                Toast.makeText(getContext(), "You're in!", Toast.LENGTH_SHORT).show();

                // Go to upcoming events screen (main screen)
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).switchToFragment(new UpcomingEventsFragment());
                }
            } else {
                Toast.makeText(getContext(), "Hmm... That didn't work, please double check your info.", Toast.LENGTH_SHORT).show();
            }
        });

        // Navigate to CreateAccountFragment
        createAccountButton.setOnClickListener(v -> {

            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new CreateAccountFragment())
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }
}