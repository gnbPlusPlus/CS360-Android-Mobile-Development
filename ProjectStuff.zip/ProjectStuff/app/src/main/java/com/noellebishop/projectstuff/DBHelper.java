package com.noellebishop.projectstuff;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.noellebishop.projectstuff.model.Event;

import java.util.ArrayList;
import java.util.List;

// Guidance was found in zyBooks and the following Geeks for Geeks articles:
// https://www.geeksforgeeks.org/android/how-to-create-and-add-data-to-sqlite-database-in-android/
// https://www.geeksforgeeks.org/android/how-to-read-data-from-sqlite-database-in-android/

public class DBHelper extends SQLiteOpenHelper {
    // Database information
    private static final String DATABASE_NAME = "planly_app.db";
    private static final int DATABASE_VERSION = 1;

    // Users Table information
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Events Table information
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "id";
    public static final String COLUMN_EVENT_NAME = "name";
    public static final String COLUMN_EVENT_DATE = "date";
    public static final String COLUMN_EVENT_USER_ID = "event_user_id";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Dynamic database creation upon app startup
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String CREATE_USERS_TABLE = " CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "  // Unique IDs are auto-designated
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // Create events table
        String CREATE_EVENTS_TABLE = "CREATE TABLE " + TABLE_EVENTS + "("
                + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_EVENT_NAME + " TEXT, "
                + COLUMN_EVENT_DATE + " TEXT, "
                + COLUMN_EVENT_USER_ID + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_EVENT_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(CREATE_EVENTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // CRUD function guidance (for users and events) was found in the following article:
    // https://clouddevs.com/android/sqlite-database/

    // User is added when account is created
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1; // true if inserted successfully
    }

    // User's login info is checked against the users table
    public int checkUserLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_USERS +
                " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(0);
            cursor.close();
            return userId;
        }
        cursor.close();
        db.close();
        return -1;  // This returns when login fails
    }


    // Event is added for a specific user
    public long addEventForUser(int userId, String name, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_EVENT_USER_ID, userId);
        values.put(COLUMN_EVENT_NAME, name);
        values.put(COLUMN_EVENT_DATE, date);

        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();
        return result;
    }

    // Events are displayed in the RecyclerView widget
    public List<Event> getAllEvents(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + COLUMN_EVENT_ID + ", " + COLUMN_EVENT_NAME + ", " + COLUMN_EVENT_DATE +
                        " FROM " + TABLE_EVENTS +
                        " WHERE " + COLUMN_EVENT_USER_ID + "=? " +
                        " ORDER BY " + COLUMN_EVENT_DATE + " ASC";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        ArrayList<Event> events = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String eventName = cursor.getString(1);
                String eventDate = cursor.getString(2);

                events.add(new Event(id, eventName, eventDate));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return events;
    }

    // Retrieve a user's saved events
    public Cursor getEventsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS +
                        " WHERE " + COLUMN_EVENT_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
    }

    // Event is updated after editing
    public boolean updateEvent(int id, String name, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, name);
        values.put(COLUMN_EVENT_DATE, date);

        int result = db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Event is deleted
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});
        return result > 0;
    }
}
