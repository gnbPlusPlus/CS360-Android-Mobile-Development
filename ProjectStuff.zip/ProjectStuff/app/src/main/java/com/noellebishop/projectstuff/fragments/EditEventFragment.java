package com.noellebishop.projectstuff.fragments;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.noellebishop.projectstuff.DBHelper;
import com.noellebishop.projectstuff.R;
import com.noellebishop.projectstuff.model.Event;

import java.util.Calendar;

public class EditEventFragment extends Fragment {

    private EditText eventNameInput;
    private Button dateButton;
    private DBHelper dbHelper;
    private Event event;
    private String selectedDate;

    public static EditEventFragment newInstance(int eventId, String eventName, String eventDate) {
        EditEventFragment fragment = new EditEventFragment();
        Bundle args = new Bundle();
        args.putInt("eventId", eventId);
        args.putString("eventName", eventName);
        args.putString("eventDate", eventDate);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_edit_event, container, false);

        eventNameInput = view.findViewById(R.id.event_input);
        dateButton = view.findViewById(R.id.date_button);
        Button doneButton = view.findViewById(R.id.allow_button);
        Button cancelButton = view.findViewById(R.id.cancel_button);

        dbHelper = new DBHelper(requireContext());

        // Get event data from arguments
        if (getArguments() != null) {
            int eventId = getArguments().getInt("eventId");
            String eventName = getArguments().getString("eventName");
            String eventDate = getArguments().getString("eventDate");

            event = new Event(eventId, eventName, eventDate); // create the Event object
        }

        eventNameInput.setText(event.getName());
        selectedDate = event.getDate();
        dateButton.setText(selectedDate);

        dateButton.setOnClickListener(v -> showDatePicker());
        doneButton.setOnClickListener(v -> saveChanges());
        cancelButton.setOnClickListener(v -> requireActivity().getSupportFragmentManager().popBackStack());

        return view;
    }

    // This function also appears in UpcomingEventsFragments.java
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(requireContext(),
                (view, year, month, dayOfMonth) -> {
                    selectedDate = (month + 1) + "/" + dayOfMonth + "/" + year;
                    dateButton.setText(selectedDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    // Very similar to addEvent() in UpcomingEventsFragment.java
    private void saveChanges() {
        String newName = eventNameInput.getText().toString().trim();

        if (newName.isEmpty() || selectedDate.isEmpty()) {
            Toast.makeText(getContext(), "Make sure you selected a name AND date!", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = dbHelper.updateEvent(event.getId(), newName, selectedDate);
        if (updated) {
            Toast.makeText(getContext(), "Event updated!", Toast.LENGTH_SHORT).show();
            requireActivity().getSupportFragmentManager().popBackStack();
        } else {
            Toast.makeText(getContext(), "Event not updated due to error.", Toast.LENGTH_SHORT).show();
        }
    }
}
