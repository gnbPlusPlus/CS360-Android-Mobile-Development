package com.noellebishop.projectstuff;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

@SuppressLint("CustomSplashScreen")  // Added in response to a compiler warning
public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 2000;  // 2 second display time

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);

        // Show launch screen for 2 seconds before going to MainActivity
        // Handler usage was modeled from zyBooks examples (6.4)
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            finish();  // Prevent going back to the launch screen
        }, SPLASH_DURATION);
    }
}