package com.noellebishop.projectstuff;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.noellebishop.projectstuff.fragments.LoginFragment;
import com.noellebishop.projectstuff.fragments.SmsFragment;
import com.noellebishop.projectstuff.fragments.UpcomingEventsFragment;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new LoginFragment())  // Start at the login screen (after launch)
                    .commit();
        }
    }

    // General logic for switching between fragments
    public void switchToFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    // Specific function for switching to UpcomingEventsFragment
    public void showUpcomingEvents() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, new UpcomingEventsFragment())
                .commit(); // don’t add login to back stack
    }

    // Specific function for switching to SmsFragment
    // (Other specific switches are handled internally in other classes)
    public void showSmsPermissionScreen() {
        switchToFragment(new SmsFragment());
    }
}