package com.noellebishop.projectstuff.fragments;

import android.Manifest;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.noellebishop.projectstuff.R;

// This fragment responds to the user tapping "allow" or "deny" on the SMS screen
public class SmsFragment extends Fragment {

    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sms, container, false);

        Button allowButton = view.findViewById(R.id.allow_button);
        Button denyButton = view.findViewById(R.id.deny_button);

        // Register the permissions callback
        // Guidance: https://developer.android.com/training/permissions/requesting
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(getContext(), "SMS permission was granted! Talk to you soon!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "SMS permission was denied. No hard feelings.", Toast.LENGTH_SHORT).show();
                    }
                    closeFragment();
                }
        );

        allowButton.setOnClickListener(v -> requestSmsPermission());
        denyButton.setOnClickListener(v -> closeFragment());

        return view;
    }

    private void requestSmsPermission() {
        requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void closeFragment() {
        requireActivity().getSupportFragmentManager().popBackStack();
    }
}