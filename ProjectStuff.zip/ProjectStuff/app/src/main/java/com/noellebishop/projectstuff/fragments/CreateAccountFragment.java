package com.noellebishop.projectstuff.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.noellebishop.projectstuff.DBHelper;
import com.noellebishop.projectstuff.MainActivity;
import com.noellebishop.projectstuff.R;

// Guidance for login and account creation functionality was found in Android documentation:
// https://developer.android.com/guide/navigation/use-graph/conditional

public class CreateAccountFragment extends Fragment {
    private EditText usernameInput, passwordInput, confirmPasswordInput;
    private DBHelper dbHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_create_account, container, false);

        usernameInput = view.findViewById(R.id.username_input);
        passwordInput = view.findViewById(R.id.password_input);
        confirmPasswordInput = view.findViewById(R.id.confirm_password_input);
        Button createAccountButton = view.findViewById(R.id.signup_button);
        Button backToLoginButton = view.findViewById(R.id.login_account_button);

        dbHelper = new DBHelper(getContext());

        // Functionality for creating the account with user input
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            if (!password.equals(confirmPassword)) {
                Toast.makeText(getContext(), "Whoops... The passwords don't match.", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.addUser(username, password)) {
                Toast.makeText(getContext(), "Your account is good to go!", Toast.LENGTH_SHORT).show();
                // Go back to login screen so user can log in with new account info
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).switchToFragment(new LoginFragment());
                }
            } else {
                Toast.makeText(getContext(), "Hmm... Try a new username, that one's taken.", Toast.LENGTH_SHORT).show();
            }
        });

        // Go back to login screen if user taps bottom button
        backToLoginButton.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new LoginFragment())
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }
}